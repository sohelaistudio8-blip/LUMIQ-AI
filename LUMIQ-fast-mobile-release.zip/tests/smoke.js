const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const must=['index.html','src/styles.css','src/js/vendor-md.js','src/js/plan.js','src/js/core.js','src/js/integrations.js','src/js/app.js','privacy.html','terms.html','favicon.svg','vercel.json'];
let bad=0;for(const f of must){const ok=fs.existsSync(path.join(root,f))&&fs.statSync(path.join(root,f)).size>0;console.log((ok?'PASS ':'FAIL ')+f);if(!ok)bad++}
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');for(const f of ['src/styles.css','src/js/vendor-md.js','src/js/plan.js','src/js/core.js','src/js/integrations.js','src/js/app.js']){if(!html.includes(f)){console.log('FAIL index references '+f);bad++}}
const integ=fs.readFileSync(path.join(root,'src/js/integrations.js'),'utf8');if(!integ.includes('awaiting_setup')){console.log('FAIL integration status transparency');bad++}else console.log('PASS integration status transparency');
const app=fs.readFileSync(path.join(root,'src/js/app.js'),'utf8');if(!app.includes('setTimeout(updateNoteResults,120)')||!app.includes('compositionend')){console.log('FAIL responsive Bengali note search');bad++}else console.log('PASS debounced IME-safe note search');
if(!/script defer src=/.test(html)||!html.includes('rel="preload"')){console.log('FAIL non-blocking asset loading');bad++}else console.log('PASS non-blocking asset loading');
process.exit(bad?1:0);
