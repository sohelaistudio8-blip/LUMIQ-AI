const {chromium}=require("playwright");const URL="file://"+require("path").resolve(__dirname,"../index.html");
const R=[];const ok=(n,c,d="")=>R.push([c?"PASS":"FAIL",n,d]);
async function pg(b,{w=360,h=640,init="",dark=false}={}){const ctx=await b.newContext({viewport:{width:w,height:h},colorScheme:dark?"dark":"light"});const p=await ctx.newPage();p.errs=[];p.net=[];
 p.on("pageerror",e=>p.errs.push(String(e)));p.on("console",m=>{if(m.type()==="error")p.errs.push(m.text())});p.on("request",r=>{if(!/^(file|data|blob):/.test(r.url()))p.net.push(r.url())});
 if(init)await ctx.addInitScript(init);await p.goto(URL);return p}
const ov=p=>p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth);
const st=p=>p.evaluate(()=>JSON.parse(localStorage.getItem("lumiq.v1")||"null"));
const nav=async(p,k)=>{await p.evaluate(k=>{location.hash=k},k);await p.waitForFunction(k=>window.__route===k,k)};
const onboard=async(p,extra={})=>{await p.click('[data-go="start"]');await p.fill("#o-n",extra.n||"Rafi");await p.fill("#o-s","Maths, Physics");await p.click('[data-a="finish"]');await p.waitForFunction(()=>window.__route==="home")};
(async()=>{const b=await chromium.launch();
// responsive on every screen × 5 widths (incl. 320)
for(const [w,h] of [[320,568],[360,640],[390,844],[768,1024],[1280,800]]){const p=await pg(b,{w,h});let g=await ov(p);
 for(const r of["start","auth"]){await nav(p,r);g=g&&await ov(p)}await nav(p,"start");await p.fill("#o-n","Rafi");await p.click('[data-a="finish"]');await p.waitForFunction(()=>window.__route==="home");
 for(const r of["home","plan","notes","cards","more","subjects","quiz","focus","revision","resources","progress","settings"]){await nav(p,r);g=g&&await ov(p)}
 ok(`no horizontal overflow @${w}px (landing, onboarding, auth, 12 app screens)`,g&&p.errs.length===0,p.errs.join("|"));await p.context().close()}
let p=await pg(b);
ok("first visit → landing with brand + tagline",(await p.textContent("h1")).includes("Unlock Your Potential.")&&(await p.textContent("header.top")).includes("LUMIQ"));
await p.click('[data-go="auth"]');await p.waitForFunction(()=>window.__route==="auth");ok("login/signup → honest 'not connected' screen",(await p.textContent("main")).includes("not connected yet"));
await p.click('[data-go="start"]');await p.waitForFunction(()=>window.__route==="start");await p.click('[data-a="finish"]');ok("onboarding requires a name",(await p.textContent("#oe")).includes("name"));
await p.fill("#o-n","Rafi");await p.fill("#o-c","Bangladesh");await p.fill("#o-s","Maths, Physics, ,English");await p.click('[data-a="finish"]');await p.waitForFunction(()=>window.__route==="home");
let d=await st(p);ok("onboarding saves profile + 3 subjects, greeting shown",d.profile.name==="Rafi"&&d.subjects.length===3&&(await p.textContent("h1")).includes("Hello, Rafi"));
ok("dashboard: AI Tutor shown as not connected; no ad/fake stats",(await p.textContent("main")).includes("not connected yet")&&(await p.textContent("main")).includes("0"));
// planner
await nav(p,"plan");await p.fill("#p-t","<img src=x onerror=window.__x=1>Read ch.1");await p.selectOption("#p-s",{index:1});await p.click('[data-a="addtask"]');
ok("planner: add (XSS as text), shown under Today",await p.evaluate(()=>window.__x===undefined&&!document.querySelector("main img")&&/Today/.test(document.querySelector("main").textContent)&&document.querySelector("main").textContent.includes("<img src=x")));
await p.fill("#p-t","Old task");await p.fill("#p-d","2020-01-01");await p.click('[data-a="addtask"]');ok("planner: overdue group",(await p.textContent("main")).includes("Overdue"));
await p.click('[data-a="tog"]');d=await st(p);ok("planner: toggle done persists",d.tasks.some(t=>t.done));
const dl=p.locator('[data-del^="tasks:"]').first();await dl.click();ok("delete needs confirm",(await st(p)).tasks.length===2);await dl.click();ok("delete confirmed",(await st(p)).tasks.length===1);
// notes
await nav(p,"notes");await p.click('[data-a="nnew"]');await p.fill("#n-t","Algebra");await p.selectOption("#n-s",{index:1});await p.fill("#n-b","# Hi\n**bold** and `x<y`\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\n[bad](javascript:window.__x=2)");
await p.click('[data-a="nprev"]');ok("notes: markdown preview safe (table, bold, no js link)",await p.evaluate(()=>{const v=document.querySelector("#pv");return!v.hidden&&v.innerHTML.includes("<table>")&&v.innerHTML.includes("<b>bold</b>")&&!v.innerHTML.includes('href="javascript')&&window.__x===undefined}));
await p.click('[data-a="nsave"]');await p.click('[data-a="nnew"]');await p.fill("#n-t","Physics note");await p.fill("#n-b","force");await p.click('[data-a="nsave"]');
await p.fill("#n-q","force");ok("notes: search filters",(await p.locator("#nl .li").count())===1);await p.fill("#n-q","");await p.selectOption("#n-f",{index:1});ok("notes: subject filter",(await p.locator("#nl .li").count())===1);
await p.locator('#nl [data-a="nopen"]').first().click();await p.fill("#n-t","Algebra v2");await p.click('[data-a="nsave"]');ok("notes: edit saved",(await st(p)).notes.some(n=>n.t==="Algebra v2"));
// flashcards + SRS
await nav(p,"cards");await p.fill("#c-q","2+2?");await p.fill("#c-a","4");await p.click('[data-a="addcard"]');await p.fill("#c-q","Capital of BD?");await p.fill("#c-a","Dhaka");await p.click('[data-a="addcard"]');
await p.click('[data-a="startrev"]');ok("cards: answer hidden until reveal",!(await p.textContent("main")).includes("Dhaka")&&!(await p.textContent("main")).includes("\n4\n"));
await p.click('[data-a="reveal"]');await p.click('[data-a="grade"][data-g="2"]');await p.click('[data-a="reveal"]');await p.click('[data-a="grade"][data-g="0"]');
d=await st(p);const tm=await p.evaluate(()=>{const x=new Date();x.setDate(x.getDate()+1);return x.getFullYear()+"-"+String(x.getMonth()+1).padStart(2,"0")+"-"+String(x.getDate()).padStart(2,"0")});
ok("cards: Good → next day; Again → due today",d.cards[0].due===tm&&d.cards[1].int===0);
// quiz
await nav(p,"quiz");await p.fill("#z-t","Maths 1");await p.selectOption("#z-s",{index:1});await p.click('[data-a="qnew"]');
await p.selectOption("#q-y","mcq");await p.fill("#q-q","2+2");await p.fill("#q-o","3\n4\n5");await p.fill("#q-a","9");await p.click('[data-a="qadd"]');ok("quiz: invalid MCQ answer rejected",(await p.textContent("#qe")).length>0);
await p.fill("#q-a","2");await p.fill("#q-x","Because 2+2=4");await p.click('[data-a="qadd"]');
await p.selectOption("#q-y","tf");await p.fill("#q-q","Earth is flat");await p.fill("#q-a","false");await p.fill("#q-o","");await p.click('[data-a="qadd"]');
await p.selectOption("#q-y","short");await p.fill("#q-q","Capital of Bangladesh");await p.fill("#q-a","Dhaka");await p.click('[data-a="qadd"]');await p.click('[data-a="qdone"]');
await p.click('[data-a="qtake"]');await p.check('input[name=q0][value="1"]');await p.check('input[name=q1][value="false"]');await p.fill("#sa2"," dhaka ");await p.click('[data-a="qsubmit"]');
ok("quiz: score 2/3, wrong answer shows correct + explanation",(await p.textContent(".big"))==="2/3"&&(await p.textContent("main")).includes("Correct: 4")&&(await p.textContent("main")).includes("Because 2+2=4"));
d=await st(p);ok("quiz: attempt saved",d.attempts.length===1&&d.attempts[0].score===2);
await nav(p,"progress");ok("progress: weak subject from real score (67% ≥ 60 → none) + quiz average shown",(await p.textContent("main")).includes("67%"));
// focus (2-second session via test hook; real timer code path)
await nav(p,"focus");await p.evaluate(()=>LQ.focusStart("focus",2));await p.waitForTimeout(2600);d=await st(p);ok("focus: session saved when timer completes",d.focus.length===1&&d.focus[0].sec===2);
await nav(p,"revision");const ex=await p.evaluate(()=>{const x=new Date();x.setDate(x.getDate()+5);return x.toISOString().slice(0,10)});await p.fill("#r-d","2020-01-01");await p.fill("#r-t","A\nB");await p.click('[data-a="rmake"]');ok("revision: past date rejected",(await p.textContent("#re")).length>0);
await p.fill("#r-d",ex);await p.click('[data-a="rmake"]');ok("revision: plan created with revision day",(await st(p)).plans[0].items.at(-1).t.startsWith("Revision"));
// resources
await nav(p,"resources");await p.fill("#u-t","Bad");await p.fill("#u-u","javascript:alert(1)");await p.click('[data-a="addres"]');ok("resources: javascript: link rejected",(await st(p)).resources.length===0);
await p.fill("#u-u","https://khanacademy.org");await p.click('[data-a="addres"]');ok("resources: https link saved, external + noopener",await p.evaluate(()=>{const a=document.querySelector("main a");return a&&a.rel.includes("noopener")&&/External link/.test(document.body.textContent)}));
// theme, language, a11y
await nav(p,"settings");await p.selectOption("#s-th","dark");await p.click('[data-a="ssave"]');ok("theme dark → #080B14",await p.evaluate(()=>getComputedStyle(document.body).backgroundColor==="rgb(8, 11, 20)"));
await p.selectOption("#s-th","light");await p.click('[data-a="ssave"]');ok("theme light → #F5F7FC",await p.evaluate(()=>getComputedStyle(document.body).backgroundColor==="rgb(245, 247, 252)"));
await p.check("#s-bg");await p.check("#s-cm");await p.click('[data-a="ssave"]');ok("larger text + reduced motion applied",await p.evaluate(()=>document.documentElement.dataset.big==="on"&&document.documentElement.dataset.calm==="on"));
await p.click('[data-a="lang"]');ok("language → বাংলা (nav + persisted)",(await p.textContent("nav")).includes("হোম")&&(await st(p)).settings.lang==="bn");await p.click('[data-a="lang"]');
ok("integrations all listed as Awaiting setup (no fake LIVE)",(await p.locator("main .bd:has-text('Awaiting setup')").count())===6);
await p.click('[data-a="export"]').catch(()=>{});
// reload persistence & deep link
await p.reload();await p.waitForFunction(()=>!!window.__route);d=await st(p);ok("data persists after reload",d.notes.length===2&&d.cards.length===2&&d.quizzes.length===1);
// back button / history
await nav(p,"notes");await nav(p,"plan");await p.goBack();ok("browser back works",await p.evaluate(()=>window.__route)==="notes");
// delete-all
await nav(p,"settings");await p.click('[data-a="wipe"]');ok("wipe needs confirmation",(await st(p))!==null);await p.click('[data-a="wipe"]');
ok("delete-all clears every lumiq key → landing",await p.evaluate(()=>Object.keys(localStorage).filter(k=>k.startsWith("lumiq.")).length===0&&window.__route==="landing"));
ok("no network requests, no page errors (main flow)",p.net.length===0&&p.errs.length===0,p.net.concat(p.errs).join("|"));await p.context().close();
// OS dark preference auto
p=await pg(b,{dark:true});ok("auto theme follows OS dark",await p.evaluate(()=>getComputedStyle(document.body).backgroundColor==="rgb(8, 11, 20)"));await p.context().close();
// storage failures
p=await pg(b,{init:'localStorage.setItem("lumiq.v1","{broken")'});await p.waitForTimeout(150);ok("corrupted data: reset, copy kept, user told, app works",await p.evaluate(()=>localStorage.getItem("lumiq.v1.bad")==="{broken"&&/unreadable/.test(document.getElementById("toast").textContent)&&window.__route==="landing"));await p.context().close();
p=await pg(b,{init:'localStorage.setItem("lumiq.v1",JSON.stringify({profile:{name:"<img src=x onerror=window.__y=1>"},tasks:[{id:1},{id:"a",t:"<b>x</b>",d:5}],settings:{theme:"hack",lang:"xx"},notes:"bad"}))'});
await nav(p,"home");await nav(p,"plan");ok("hostile stored data sanitized, shown as text, nothing executes",await p.evaluate(()=>window.__y===undefined&&!document.querySelector("main img")&&document.documentElement.dataset.theme===undefined));await p.context().close();
p=await pg(b,{init:'Storage.prototype.setItem=function(){throw new DOMException("q","QuotaExceededError")}'});await p.click('[data-go="start"]');await p.fill("#o-n","Z");await p.click('[data-a="finish"]');await p.waitForFunction(()=>window.__route==="home");
ok("storage blocked: app still works in memory and user is told",/Couldn’t save/.test(await p.textContent("#toast"))&&p.errs.length===0,p.errs.join("|"));await p.context().close();
await b.close();for(const r of R)console.log(r.join(" | "));console.log("TOTAL",R.length,"FAIL",R.filter(r=>r[0]==="FAIL").length);process.exit(R.some(r=>r[0]==="FAIL")?1:0)})().catch(e=>{console.log("HARNESS ERROR",e);for(const r of R)console.log(r.join(" | "));process.exit(2)});
