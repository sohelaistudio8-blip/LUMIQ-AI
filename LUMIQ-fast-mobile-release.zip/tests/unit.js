const fs=require("fs"),p=f=>fs.readFileSync(__dirname+"/../src/js/"+f,"utf8");
const g=new Function(p("vendor-md.js")+p("plan.js")+`let LQ;`+p("core.js").replace("window.LQ=","LQ=").replace(/localStorage/g,"({getItem(){return null},setItem(){},removeItem(){},})")+";return{md,esc,mkPlan,addDays,LQ}")();
let f=0;const T=(n,c)=>{console.log((c?"PASS ":"FAIL ")+n);if(!c)f++};
const r=g.md("# T\n**b** [l](https://x.com) [j](javascript:alert(1))\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n```js\nx<1\n```\n<img src=x onerror=alert(1)>");
T("md: heading/bold/table/code",r.includes("<h3>T</h3>")&&r.includes("<b>b</b>")&&r.includes("<table>")&&r.includes("x&lt;1"));
T("md: html escaped, javascript: not linked",!r.includes("<img")&&!r.includes('href="javascript'));
const u=()=>"i"+Math.random();let pl=g.mkPlan("2026-11-08","A\nB\nC","2026-11-02",u);
T("plan: 6 items, ends with revision",pl.plan.length===6&&pl.plan.at(-1).t.startsWith("Revision"));
T("plan: errors",!!g.mkPlan("2026-11-01","A","2026-11-02",u).err&&!!g.mkPlan("2026-11-08","","2026-11-02",u).err);
T("plan: rejects impossible calendar dates",!!g.mkPlan("2026-02-30","A","2026-02-01",u).err);
T("answer normalization: case, spaces and Unicode compatibility",g.LQ.normalizeAnswer("  Ａ  B  ")==="a b");
const s=g.LQ.sm2,t0="2026-11-02";let c=s({},2,t0);
T("sm2: first Good → due +1 day",c.int===1&&c.due==="2026-11-03");
c=s(c,2,t0);T("sm2: second Good → 6 days",c.int===6&&c.due==="2026-11-08");
c=s(c,2,t0);T("sm2: third Good grows by ease",c.int>=14);
T("sm2: Again resets, due today, ease drops",(x=>x.reps===0&&x.due===t0&&x.ease<2.5)(s(c,0,t0)));
T("sm2: ease never below 1.3",(()=>{let x={};for(let i=0;i<20;i++)x=s(x,0,t0);return x.ease>=1.3})());
console.log(f?f+" FAILED":"ALL PASS");process.exit(f?1:0)
